Qt.include("../common/EnumHelper.js")
Qt.include("../common/DateTime.js")

//////////////////////////////////////////////////////////////////////////
// Helpers

function localizeFileSize(fileSize, localizer)
{
	var	DigitGroupSize = 1024;
	var	DigitGroupCount = 4;

	var suffixes = [ "KBSuffix", "MBSuffix", "GBSuffix", "TBSuffix" ];

	var remainder = fileSize;
	var position = 0;
	while(remainder >= DigitGroupSize)
	{
		if(DigitGroupCount == position)
			break;
		remainder /= DigitGroupSize;
		++position;
	}
	if(!position)
	{
		remainder /= DigitGroupSize;
		++position;
	}
	var result = remainder.toFixed(2).toString(10);
	result += " ";
	result += localizer.Localize(suffixes[position - 1]);
	return result;
}

function getUserIconLocalizationKey(userCount)
{
    if (userCount < 10)
        return "FileKSNUsersLess10";
    else if (userCount < 100)
        return "FileKSNUsersLess100";
    else if (userCount < 1000)
        return "FileKSNUsersLess1000";
    else if (userCount < 10000)
        return "FileKSNUsersMore1000";
    else if (userCount < 100000)
        return "FileKSNUsersMore10000";
    else if (userCount < 1000000)
        return "FileKSNUsersMore100000";
	return "FileKSNUsersMoreMillion";
}

function localizeCountries(list, localizer)
{
    var retval = "";
    for (var i = 0; i < list.length; ++i)
    {
        if(retval != "")
            retval += localizer.Localize("ListDelimiter");
        retval += localizer.Localize("CountryElement", { "CountryName": localizer.Localize(list[i].country), "CountryPercent": list[i].percent });
    }
    return retval;
}


//////////////////////////////////////////////////////////////////////////
// 
function getLabel(tr, context, enumName, listItem)
{
    var fieldType = EnumExtension.ConvertToEnumKey(context, enumName, listItem.type);
	switch(fieldType)
	{
	    // basic info
	    case "Field_File":
            return tr.Localize("FileLabel");
	    case "Field_Type":
	        return tr.Localize("TypeLabel");
	    case "Field_Application":
	        return tr.Localize("ApplicationLabel");
	    case "Field_Company":
	        return tr.Localize("CompanyLabel");
	    // detail info
	    case "Field_Path":
	        return tr.Localize("PathLabel");
        case "Field_Version":
	        return tr.Localize("VersionLabel");
	    case "Field_Size":
	        return tr.Localize("SizeLabel");
	    case "Field_CreationTime":
	        return tr.Localize("CreatedLabel");
	    case "Field_ModifiedTime":
	        return tr.Localize("ModifiedLabel");
	    // ksn info icons
	    case "Field_Ksn":
	        return "";
	    case "Field_KsnFile":
	        return "";
	    case "Field_KsnFileDigital":
	        return "";
	    case "Field_KsnUsers":
	        return "";
	    // appearance info
	    case "Field_FirstAppeared":
	        return tr.Localize("FirstAppearedLabel");
	    case "Field_DistributionArea":
	        return tr.Localize("GeographyLabel");
	    // security rate
	    case "Field_UserRate":
	        return tr.Localize("UserRatingLabel");
	    case "Field_Signer":
	        return tr.Localize("SignerLabel");
	    case "Field_SignatureDate":
	        return tr.Localize("SignatureDateLabel");
	    // history
	    case "Field_HistoryFileOp":
	        return tr.Localize("HistoryFileOp");
	    case "Field_HistoryMailOp":
	        return tr.Localize("HistoryMailOp");
	    case "Field_HistoryUrlOp":
	        return tr.Localize("HistoryUrlOp");
	    case "Field_HistoryIcwOp":
	        return tr.Localize("HistoryIcwOp");
        default:
	};
	return "";
}

function getValue(tr, context, enumName, listItem)
{
    var fieldType = EnumExtension.ConvertToEnumKey(context, enumName, listItem.type);
    switch (fieldType)
    {
        // basic info  
        case "Field_File":
            return context.fileDisplayName
        case "Field_Type":
            return context.fileType;
        case "Field_Application":
            return context.fileDisplayName;
        case "Field_Company":
            return context.company;
            // detail info
        case "Field_Path":
            return context.filePath;
        case "Field_Version":
            return context.fileVersion;
        case "Field_Size":
            return localizeFileSize(context.fileSize, tr);
        case "Field_CreationTime":
            return localizeDateTime(context.creationTime, "ShortDateTimeFormat", tr);
        case "Field_ModifiedTime":
            return localizeDateTime(context.modificationTime, "ShortDateTimeFormat", tr);
            // ksn info icons
        case "Field_Ksn":
            return context.isTrusted ? tr.Localize("TrustedKSN") : tr.Localize("NotTrustedKSN");
        case "Field_KsnFile":
            {
                var postfix = getApproximatePeriodPostfix(helperConvertToTimeDuration(context.firstRequest));
                return tr.LocalizeOptional("FileAge_" + postfix, "Unknown");
            }
        case "Field_KsnFileDigital":
            return tr.Localize("TrustedSignature");
        case "Field_KsnUsers":
            return tr.Localize(getUserIconLocalizationKey(context.userCount));
            // appearance info
        case "Field_FirstAppeared":
            {
                if (context.isTrusted)
                    return tr.Localize("FirstAppeared", { "LiteralFileAge": localizeApproximatePeriodFromDate(context.firstRequest, tr) });
                return "";
            }
        case "Field_DistributionArea":
            return localizeCountries(context.countries, tr);
            // security rate
        case "Field_UserRate":
            return tr.Localize("UserRating", { "TrustingUsers": context.trustedPerc, "RestrictingUsers": context.hiRestPerc, "BlockingUsers": context.untrustedPerc });
        case "Field_Signer":
            return context.signerOrganization;
        case "Field_SignatureDate":
            return localizeDateTime(context.signedTime, "ShortDateTimeFormat", tr);
        // history
        case "Field_HistoryFileOp":
        case "Field_HistoryMailOp":
        case "Field_HistoryUrlOp":
        case "Field_HistoryIcwOp":
            return listItem.value;

        default:
    };
    return "";
}