function onButtonClick(path)
{
    try
    {
        Statistics.onButtonClick(path);
    }
    catch(e)
    {
        console.log("Statistics::onButtonClick for " + path + " failed - " + e);
    }
}

function onNavigateTo(objectName)
{
    try
    {
        Statistics.onNavigateTo(objectName);
    }
    catch(e)
    {
        console.log("Statistics::onNavigateTo " + objectName + " failed - " + e);
    }
}
