var ParentalControlPasswordInputHelpId = 39471
var ParentalControlAccountListHelpId = 25657
var ParentalControlPasswordAreaHelpId = 45200

var ActivationBasePageHelpId = 44437
var ActivationPageHasLicenseHelpId = 47152
var ActivationPageNoConnectionHelpId = 44618
var ActivationPageOtherProductHelpIdKIS = 63218
var ActivationPageOtherProductHelpIdKAV = 44614
var ActivationPageRegistrationHelpId = 44617
var ActivationPageFailedHelpId = 39359
var ActivationPagePurchasingHelpId = 61711

var KsnAboutCloudProtectionHelpId = 47101
var KsnOnlineServicesHelpId = 44958

var LicenseManagerHelpId = 44436

var MainWindowAdvancedToolsHelpId = 43660
var MainWindowHelpId = 39838
var MainWindowSearchHelpId = 44623

var MigrationSearchManualRemovalApplicationsHelpId = 46835
var MigrationAppListPageHelpId = 46828
var MigrationRebootPageHelpId = 46840
var MigrationUpgradeHelpId = 44433

var NewsItemHelpId = 44290
var NewsListHelpId = 44289

var ProblemListHelpId = 44712

var SafeBankingHelpId = 60014
var SafeBankingRulesDialogHelpId = 59948
var SafeBankingDefaultRulesDialogHelpId = 60755

var ScanHelpId = 43663

var AntiBannerSettingsHelpId = 25943
var AntiSpamSettingsHelpId = 25785
var AppearanceSettingsHelpId = 15352
var ApplicationControlSettingsHelpId = 24718
var BatterySavingSettingsHelpId = 26520
var CompatibilitySettingsHelpId = 26521
var FeedbackSettingsHelpId = 24392
var FileMonitorSettingsHelpId = 24481
var FirewallSettingsHelpId = 24817
var GamingProfileSettingsHelpId = 24437
var GeneralSettingsHelpId = 14868
var ImMonitorSettingsHelpId = 24692
var IntrusionDetectorSettingsHelpId = 25780
var MailMonitorSettingsHelpId = 24538
var ManageSettingsHelpId = 14892
var NetworkSettingsHelpId = 15308
var NotificationsSettingsHelpId = 24350
var ParentalControlSettingsHelpId = 26535
var ReportsAndQuarantineSettingsHelpId = 15337
var SafeBankingSettingsHelpId = 59945
var ScanGeneralSettingsHelpId = 14851
var ScanMyComputerSettingsHelpId = 23878
var ScanObjectsSettingsHelpId = 23898
var ScanStartupSettingsHelpId = 23895
var ScanVulnerabilitiesSettingsHelpId = 23899
var SelfDefenceSettingsHelpId = 26519
var SystemWatcherSettingsHelpId = 26040
var ThreatsAndExclusionSettingsHelpId = 15303
var UpdaterSettingsHelpId = 15909
var WebMonitorSettingsHelpId = 24621
var VirtualKeyboardSettingsHelpId = 60080
var SecureKeyboardSettingsHelpId = 60081

var VirtualKeyboardExclusionsSettingsHelpId = 60122
var SecureKeyboardExclusionsSettingsHelpId = 60151
var VirtualKeyboardCategoriesSettingsHelpId = 61229
var SecureKeyboardCategoriesSettingsHelpId = 61228

var VirtualKeyboardIncludeHelpId = 60139
var VirtualKeyboardExcludeHelpId = 60146
var SecureKeyboardIncludeHelpId = 60166
var SecureKeyboardExcludeHelpId = 60173

var UpdaterHelpId = 44713
var SendDumpsHelpId = 60028

var SupportMainHelpId = 26122
var SupportMonitoringHelpId = 59996
var SupportReportFilesHelpId = 60041
var SupportSendTroublesHelpId = 60028

