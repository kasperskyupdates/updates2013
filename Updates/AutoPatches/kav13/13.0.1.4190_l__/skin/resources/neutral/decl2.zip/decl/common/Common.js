function buildPath(item)
{
    var path = "";
    while (item)
    {
        path = (item.objectName ? item.objectName : item) + (path ? "." + path : "");
        item = item.parent;
    }
    var rg = new RegExp("\\.QDeclarativeItem.*\\.", "g");
    return path.replace(rg, ".QDeclarativeItem.");
}

function buildDelegatelessPath(item)
{
    var path = "";
    while (item)
    {
        var pathChunk = item.objectName ? item.objectName : item;
        // test next element first
        if (item.parent)
        {
            var itemType = new String(item.parent.valueOf());
            if (itemType.indexOf("QDeclarativeListView") != -1 || itemType.indexOf("QDeclarativeGridView") != -1)
                pathChunk = "Delegate";
        }
        path = pathChunk + (path ? "." + path : "");
        item = item.parent;
    }
    var rg = new RegExp("\\.QDeclarativeItem.*\\.", "g");
    return path.replace(rg, ".QDeclarativeItem.");
}

function getShortFileSizeString(size)
{
    var result = size;
    var denominator = 0;
    while(result > 1024)
    {
        result /= 1024;
        denominator += 1;
    }
    return denominator;
}

function getFileSizeSuffix(denominator)
{
    switch(denominator)
    {
    case 0: return "B";
    case 1: return "KB";
    case 2: return "MB";
    case 3: return "GB";
    case 4: return "TB";
    }
}
