var verticalCaptionToCommonText = 6
var verticalCommonTextToWidget = 14
var horizontalBetweenButtons = 8
var commonTextLineHeight = 1.1