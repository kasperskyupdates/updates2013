function convert(obj, prop, in_map)
{
	function reportError(msg)
	{
		console.log("Error in convert " + obj + "." + prop + ": " + msg);
		return "";
    }
    if (!obj)
        return "";
	var count = 0;
	var map = [];
	for (var i in in_map)
	{
		var num = EnumExtension.KeyToValue(i, obj, prop);
		if (num == -1) return reportError("enum doesn't contain '" + i + "'");
		map[num] = in_map[i];
		++count;
	}
	if (EnumExtension.GetCount(obj, prop) != count)
	    reportError("count mismatch have " + count + " but expected " + EnumExtension.GetCount(obj, prop));
    var retval = map[obj[prop]];
    return InjectBinding(obj, prop) ? retval : retval;
}

function getKey(obj, prop)
{
    var retval = obj ? EnumExtension.GetKey(obj, prop) : "";
    return InjectBinding(obj, prop) ? retval : retval;
}

// Helper function for injecting dependency for a property passed only with a string name
// Black magic: evaluation of this script is making a binding for a specified property
function InjectBinding(obj, prop)
{
    return eval("obj." + prop);
}
