//////////////////////////////////////////////////////////////////////////
// Helpers

function helperFillMonthNames(localizer)
{
    var months = [];
	for(var i = 1; i <= 12; ++i)
	{
	    months.push(localizer.Localize("MonthName_" + i));
	}
	return months;
}

function helperGetTotalSeconds(timeDuration) // timeDuration in ms
{
    return timeDuration / 1000;
}

function helperSelectRelativeSuffix(timeDuration)
{
	var seconds = helperGetTotalSeconds(timeDuration);
	if(seconds > 60)
		return "_After";
	else if(seconds > 0)
		return "_Remaining";
	return "_Ago";
}

function helperConvertToTimeDuration(localDateTime)
{
	var now = new Date();
	return localDateTime - now;
}

//////////////////////////////////////////////////////////////////////////
// Converters

function convertUTCToLocal(utcDateTime)
{
    var local = new Date();
    local.setUTCFullYear(utcDateTime.getFullYear());
    local.setUTCMonth(utcDateTime.getMonth());
    local.setUTCDate(utcDateTime.getDate());
    local.setUTCHours(utcDateTime.getHours());
    local.setUTCMinutes(utcDateTime.getMinutes());
    local.setUTCSeconds(utcDateTime.getSeconds());
    local.setUTCMilliseconds(utcDateTime.getMilliseconds());
    return local;
}

//////////////////////////////////////////////////////////////////////////
// Approximate period localizers

function getApproximatePeriodPostfix(timeDuration)
{
	var secondsInDay = 60 * 60 * 24;
	var secondsInWeek = secondsInDay * 7;
	var secondsInYear = secondsInDay * 365.25;
	var secondsInMonth = secondsInYear / 12.0;

    var resultPostfix = "";

	if(isNaN(timeDuration))
		return resultPostfix;

	var seconds = Math.abs(helperGetTotalSeconds(timeDuration));
	if(seconds < secondsInDay)
		resultPostfix = "Today";
	else if(seconds < secondsInDay * 2)
		resultPostfix = "Yesterday";
	else if(seconds < secondsInWeek)
		resultPostfix = "LessWeek";
	else if(seconds < secondsInWeek * 2)
		resultPostfix = "LessTwoWeek";
	else if(seconds < secondsInMonth)
		resultPostfix = "LessMonth";
	else if(seconds > secondsInYear)
		resultPostfix = "MoreYear";
	else if(seconds > secondsInYear/2)
		resultPostfix = "MoreHalfYear";
	else
		resultPostfix = "MoreMonth";

	return resultPostfix;
}

function localizeApproximatePeriod(timeDuration, localizer)
{
	if(isNaN(timeDuration))
		return localizer.Localize("DateUnknown");
	
	return localizer.Localize(getApproximatePeriodPostfix(timeDuration));
}

function localizeApproximatePeriodFromDate(dateTime, localizer)
{
	if (isNaN(dateTime.getTime()))
        return localizer.Localize("DateUnknown");
	return localizeApproximatePeriod(helperConvertToTimeDuration(dateTime), localizer);
}

//////////////////////////////////////////////////////////////////////////
// Concrete time localizers

function localizeTimeInterval(timeDuration, localizer)
{
	var secondsInDay = 86400;
	var secondsInHour = 3600;
	var secondsInMinute = 60;

	if(isNaN(timeDuration))
		return localizer.Localize("DateUnknown");

	var absSeconds = Math.abs(helperGetTotalSeconds(timeDuration));
	var relativeSuffix = helperSelectRelativeSuffix(timeDuration);

	var timePeriodText = "";
	if(absSeconds > secondsInDay)
	{
	    var days = absSeconds/secondsInDay;
		timePeriodText = localizer.Localize("Days" + relativeSuffix, {"DayCount" : days.toFixed(0)});
	}
	else if(absSeconds > secondsInHour)
	{
	    var hours = absSeconds/secondsInHour;
		timePeriodText = localizer.Localize("Hours" + relativeSuffix, {"HourCount" : hours.toFixed(0)});
	}	
	else if(absSeconds > secondsInMinute)
	{
	    var minutes = absSeconds/secondsInMinute;
		timePeriodText = localizer.Localize("Minutes" + relativeSuffix, {"MinuteCount" : minutes.toFixed(0)});
	}	
	else 
		timePeriodText = localizer.Localize("LessMinute" + relativeSuffix);

	return timePeriodText;
}

function localizeTimeIntervalFromDate(dateTime, localizer)
{
    if (isNaN(dateTime.getTime()))
        return localizer.Localize("DateUnknown");

    return localizeTimeInterval(helperConvertToTimeDuration(dateTime), localizer);
}

function localizeTimeIntervalFullFormat(timeDuration, localizer)
{
	if(isNaN(timeDuration))
	    return localizer.Localize("DateUnknown");

	var timePeriodText = localizeTimeInterval(timeDuration, localizer);
	return localizer.Localize("Time" + helperSelectRelativeSuffix(timeDuration), {"TimePeriod" : timePeriodText});
}

function localizeTimeIntervalFromDateFullFormat(dateTime, localizer)
{
    if (isNaN(dateTime.getTime()))
        return localizer.Localize("DateUnknown");

    return localizeTimeIntervalFullFormat(helperConvertToTimeDuration(dateTime), localizer);
}

function localizeTimeIntervalFromDaysCount(daysCount, localizer)
{
    var timeDuration = 1000 * 60 * 60 * 24 * daysCount;
	return localizeTimeInterval(timeDuration, localizer);
}

//////////////////////////////////////////////////////////////////////////
// Localize time

function localizeDateTimeForNews(dateTime, localizer, emptyValue) {
    var dateFormat,
    millisecondsInDay = 24 * 60 * 60 * 1000;

    if (isNaN(dateTime.getTime()))
        return emptyValue ? emptyValue : localizer.Localize("DateUnknown");

    if (Math.floor(dateTime.getTime() / millisecondsInDay) == Math.floor((new Date).getTime() / millisecondsInDay)) {
        dateFormat = 'ShortDateTimeNewsTodayFormat';
    } else if (Math.floor(dateTime.getTime() / millisecondsInDay) === (Math.floor(((new Date).getTime() - millisecondsInDay) / millisecondsInDay))) {
        dateFormat = 'ShortDateTimeNewsYesterdayFormat';
    } else {
        dateFormat = 'ShortDateTimeNewsFormat';
    }

    var monthsNames = helperFillMonthNames(localizer);
    return localizer.LocalizeDateTimeCustom(dateTime, localizer.Localize(dateFormat), monthsNames);
}

function localizeDateTime(dateTime, formatKey, localizer, emptyValue)
{
	if (isNaN(dateTime.getTime()))
        return emptyValue ? emptyValue : localizer.Localize("DateUnknown");

	var dateFormat = formatKey != "" ? localizer.Localize(formatKey) : "";
    var monthsNames = helperFillMonthNames(localizer);
    return localizer.LocalizeDateTimeCustom(dateTime, dateFormat, monthsNames);
}
