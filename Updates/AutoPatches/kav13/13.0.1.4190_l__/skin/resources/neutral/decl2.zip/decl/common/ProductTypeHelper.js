Qt.include("EnumHelper.js")

function productTypeToString(context)
{
    return convert(context, "productType", {
		"KasperskyInternetSecurity":"kis",
		"KasperskyAntiVirus":"kav",
		"KasperskyAntiVirusForWorkstation":"wks",
		"KasperskyAntiVirusForFileServer":"wfs",
		"KasperskyAntiVirusTool":"kat",
		"KasperskyRescueDisk":"rd",
		"Pure":"pure",
		"Unknown":"unk"});
}

function isKIS()
{
    return (getKey(Global, "productType") == "KasperskyInternetSecurity");
}

function getPostfixByProductType(context, field)
 {
     return convert(context, field, {
        "KasperskyInternetSecurity": "_KIS",
        "KasperskyAntiVirus": "_KAV",
        "KasperskyAntiVirusTool": "_KAT",
        "KasperskyAntiVirusForWorkstation":"",
		"KasperskyAntiVirusForFileServer":"",
		"KasperskyRescueDisk":"",
		"Pure":"",
		"Unknown":""
    });
}

function getProductNameEx(localizer, context, suffix, isBeta)
{
    return localizer.Localize("ProductName_" + productTypeToString(context) + (isBeta ? "_Beta" : "" ) + suffix);
}

function getProductName(localizer, context)
{
    return getProductNameEx(localizer, context, "");
}

function getProductNameFull(localizer, context, isBeta)
{
    return getProductNameEx(localizer, context, "_Full", isBeta);
}

function getProductNameShort(localizer, context)
{
    return getProductNameEx(localizer, context, "_Short");
}