var backStateStack = [];
var onChangedActions = [];

function logStatistic(id, currentState, toState)
{
    if (id && id.objectName) id = id.objectName;
	Statistics.onNavigateTo(id + "");
}

function toState(id, state, backFunction /*Optional*/)
{
	if (backStateStack.length != 0 && backStateStack[backStateStack.length - 1].object == id) return;
	logStatistic(id);
	backStateStack.push({"object":id, "state":id.state, "backFunction":backFunction});
	id.state = state;
	id.z = 1;
	performeOnChangedActions();
}

function show(id, backFunction /*Optional*/)
{
    if (backStateStack.length != 0)
	    backStateStack[backStateStack.length - 1].object.z = 0;
	toState(id, "Show", backFunction);
}

function doBack()
{
	if (backStateStack.length == 0) return;
	var back = backStateStack.pop();
	back.object.state = back.state;
	if (back.backFunction) back.backFunction();
	performeOnChangedActions();
	if (backStateStack.length != 0)
	    logStatistic(backStateStack[backStateStack.length - 1].id);
}

function goTop()
{
	while (backStateStack.length != 0) doBack();
}

function atTop()
{
	return backStateStack.length == 0;
}

function getCurrent()
{
	return backStateStack.length == 0 ? null : backStateStack[backStateStack.length - 1].object;
}

function registerOnChangedAction(action)
{
	onChangedActions.push(action);
}

function performeOnChangedActions()
{
	for (var i in onChangedActions) onChangedActions[i]();
}

function findViewManager(item)
{
	for (; item != undefined; item = item.parent)
		if (typeof item.viewManager == 'function')
			return item.viewManager();
}
