function makeWindowSkinCommand(windowName)
{
    return "window(\"" + windowName + "\")";
}
function makeWindowSkinCommandNoQuotes(windowName)
{
    return "window(" + windowName + ")";
}

var generalSearchData = [
        {
            listItem : "Scan_Search",
            panel : "panelScan",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_scan_green.png",
            searchKeys : "ScanSearchKeys"
        },
        {
            listItem : "Tools_Search",
            panel : "panelTools",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_tools_48_green.png",
            searchKeys : "ToolsSearchKeys"
        },
        {
            listItem : "VirtualKeyboard_Search",
            panel : undefined,
            oldAction: "f_ShowVirtualKeyboard()",
            imageSource: "../common/images/main_window/search/ico_virtual_keyboard_green.png",
            searchKeys : "VirtualkeyboardSearchKeys"
        },
        {
            listItem : "Quarantine_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QB_Storage"),
            imageSource: "../common/images/main_window/search/ico_quarantine_green.png",
            searchKeys : "QuarantineSearchKeys"
        },
        {
            listItem : "Support_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLSupport"),
            imageSource: "../common/images/main_window/search/ico_support_green.png",
            searchKeys : "SupportSearchKeys"
        },
        {
            listItem : "Updater_Search",
            panel : "panelUpdater",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_update_bases_green.png",
            searchKeys : "UpdaterSearchKeys"
        },
        {
            listItem : "LicenseManager_Search",
            panel : "panelLicenseManager",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_license_management_green.png",
            searchKeys : "LicenseManagerSearchKeys"
        },
        {
            listItem : "About_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLAbout"),
            imageSource: "../common/images/main_window/search/ico_about_green.png",
            searchKeys : "AboutSearchKeys"
        },
];
var kisSpecificSearchData = [
        {
            listItem : "ParentalControl_Search",
            panel : "panelParentalControl",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_parental_control_green.png",
            searchKeys : "ParentalControlSearchKeys"
        },
        {
            listItem : "NetworkMonitoring_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("NetworkMonitor"),
            imageSource: "../common/images/main_window/search/ico_network_monitoring_green.png",
            searchKeys : "NetworkMonitoringSearchKeys"
        },
        {
            listItem : "ProgramsActivity_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("SystemMonitor:Programs:Running"),
            imageSource: "../common/images/main_window/search/ico_application_control_green.png",
            searchKeys : "ProgramsActivitySearchKeys"
        },
        {
            listItem : "SafeBanking_Search",
            panel : "panelSafeBanking",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_support_green.png",
            searchKeys : "SafeBankingSearchKeys"
        },
];
var kavSpecificSearchData = [
        {
            listItem : "Upgrade_Search",
            panel : "panelUpgrade",
            oldAction: undefined,
            imageSource: "../common/images/main_window/search/ico_product_update_green.png",
            searchKeys : "UpgradeSearchKeys"
        },
];
var settingsSearchData = [
        {
            listItem : "ScanSettings_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLSettings:ScanGeneral"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "ScanSettingsSearchKeys"
        },
        {
            listItem : "FullScanSettings_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLSettings:ScanMyComputer"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "FullScanSettingsSearchKeys"
        },
        {
            listItem : "CriticalScanSettings_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLSettings:ScanStartup"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "CriticalScanSettingsSearchKeys"
        },
        {
            listItem : "CustomScanSettings_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLSettings:ScanObjects"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "CustomScanSettingsSearchKeys"
        },
        {
            listItem : "VulnerabilitiesScanSettings_Search",
            panel : undefined,
            oldAction: makeWindowSkinCommand("QMLSettings:ScanVulnerabilities"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "VulnerabilitiesScanSettingsSearchKeys"
        },
        {
            listItem : "UpdaterSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Updater"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "UpdaterSettingsSearchKeys"
        },

        {
            listItem : "GeneralProtectionSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:General"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "GeneralProtectionSettingsSearchKeys"
        },
        {
            listItem : "File_MonitoringSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:FileMonitor"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "File_MonitoringSettingsSearchKeys"
        },
        {
            listItem : "Mail_MonitoringSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:MailMonitor"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "Mail_MonitoringSettingsSearchKeys"
        },
        {
            listItem : "Web_MonitoringSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:WebMonitor"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "Web_MonitoringSettingsSearchKeys"
        },
        {
            listItem : "IM_MonitoringSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:ImMonitor"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "IM_MonitoringSettingsSearchKeys"
        },
        {
            listItem : "SW2Settings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:SystemWatcher"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "SW2SettingsSearchKeys"
        },
        {
            listItem : "ThreatsSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:ThreatsAndExclusion"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "ThreatsSettingsSearchKeys"
        },
        {
            listItem : "SelfProtSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:SelfDefence"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "SelfProtSettingsSearchKeys"
        },
        {
            listItem : "BatterySettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:BatterySaving"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "BatterySettingsSearchKeys"
        },
        {
            listItem : "CompatibilitySettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Compatibility"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "CompatibilitySettingsSearchKeys"
        },
        {
            listItem : "TrafficSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Network"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "TrafficSettingsSearchKeys"
        },
        {
            listItem : "NotificationsSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Notifications"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "NotificationsSettingsSearchKeys"
        },
        {
            listItem : "ReportsSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:ReportsAndQuarantine"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "ReportsSettingsSearchKeys"
        },
        {
            listItem : "FeedbackSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Feedback"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "FeedbackSettingsSearchKeys"
        },
        {
            listItem : "ProfilesSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:GamingProfile"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "ProfilesSettingsSearchKeys"
        },
        {
            listItem : "GuiSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Appearance"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "GuiSettingsSearchKeys"
        },
        {
            listItem : "ManageSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:ManageSettings"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "ManageSettingsSearchKeys"
        },
];
var kisSpecificSettingsSearchData = [
        {
            listItem : "SafeBankingSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:SafeBanking"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "SafeBankingSettingsSearchKeys"
        },
        {
            listItem : "HipsTaskSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:ApplicationControl"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "HipsTaskSettingsSearchKeys"
        },
        {
            listItem : "FirewallSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:Firewall"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "FirewallSettingsSearchKeys"
        },
        {
            listItem : "IdsSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:IntrusionDetector"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "IdsSettingsSearchKeys"
        },
        {
            listItem : "Anti_SpamSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:AntiSpam"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "Anti_SpamSettingsSearchKeys"
        },
        {
            listItem : "AdBlockerSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:AntiBanner"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "AdBlockerSettingsSearchKeys"
        },
        {
            listItem : "ParCtlSettings_Search",
            panel : undefined,
            oldAction : makeWindowSkinCommand("QMLSettings:ParentalControl"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys : "ParCtlSettingsSearchKeys"
        },
        {
            listItem: "ProtectedInputSettings_Search",
            panel: undefined,
            oldAction: makeWindowSkinCommand("QMLSettings:ProtectedInput"),
            imageSource: "../common/images/main_window/search/ico_options_green.png",
            searchKeys: "ProtectedInputSettingsSearchKeys"
        },
];
