function GetPageContext(obj, name)
{
    var pageCtx;
    try
    {
        pageCtx = obj.pages.GetPageContext(name);
    }
    catch(err)
    {
        console.log("GetPageContext failed")
    }

    if (!pageCtx)
        pageCtx = obj.pagesContext[name];

    return pageCtx;
}
